package capability_probe_test

import (
	"context"
	"errors"
	"os"
	"strings"
	"testing"

	"github.com/faustbrian/go-capability"
)

func TestNilPanicNeverReportsTransportSuccess(t *testing.T) {
	bytes, err := os.ReadFile("../../testdata/v1-hmac.token")
	if err != nil {
		t.Fatal(err)
	}
	proof, err := capability.ParseProof(strings.TrimSpace(string(bytes)), capability.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	err = proof.Transfer(context.Background(), func(context.Context, []byte) error { panic(nil) })
	if !errors.Is(err, capability.ErrProofTransferFailed) {
		t.Fatalf("nil panic reported success: %v", err)
	}
}
