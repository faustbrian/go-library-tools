package main

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/faustbrian/go-capability"
)

func main() {
	golden, err := os.ReadFile("testdata/v1-hmac.token")
	if err != nil {
		panic("fixture unavailable")
	}
	proof, err := capability.ParseProof(strings.TrimSpace(string(golden)), capability.DefaultLimits())
	if err != nil {
		panic("proof parse failed")
	}
	err = proof.Transfer(context.Background(), func(_ context.Context, borrowed []byte) error {
		fmt.Printf("golden proof borrow len=%d cap=%d spare=%d\n", len(borrowed), cap(borrowed), cap(borrowed)-len(borrowed))
		return nil
	})
	if err != nil {
		panic("transfer failed")
	}
}
