module github.com/faustbrian/go-authorization/integration/contracts

go 1.26.6

require (
	github.com/faustbrian/go-authentication v1.0.0
	github.com/faustbrian/go-authorization v1.0.0
	github.com/faustbrian/go-log v1.0.0
	github.com/faustbrian/go-telemetry v1.0.0
)

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/faustbrian/go-clock v1.0.0 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/google/uuid v1.6.0 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/otel v1.44.0 // indirect
	go.opentelemetry.io/otel/metric v1.44.0 // indirect
	go.opentelemetry.io/otel/sdk v1.44.0 // indirect
	go.opentelemetry.io/otel/sdk/metric v1.44.0 // indirect
	go.opentelemetry.io/otel/trace v1.44.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
)

replace github.com/faustbrian/go-authentication => /private/tmp/identity-platform-consumer-gates.9IxpDN/snapshots/authentication

replace github.com/faustbrian/go-authorization => /private/tmp/identity-platform-consumer-gates.9IxpDN/snapshots/authorization

replace github.com/faustbrian/go-capability => /private/tmp/identity-platform-consumer-gates.9IxpDN/snapshots/capability
