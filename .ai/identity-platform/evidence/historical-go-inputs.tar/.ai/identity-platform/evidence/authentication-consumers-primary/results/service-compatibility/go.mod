module github.com/faustbrian/go-service/compatibility

go 1.26.6

require (
	github.com/faustbrian/go-authentication v1.2.0
	github.com/faustbrian/go-authorization v1.0.0
	github.com/faustbrian/go-config v1.1.0
	github.com/faustbrian/go-log v1.0.0
	github.com/faustbrian/go-queue v1.0.0
	github.com/faustbrian/go-scheduler v1.1.0
	github.com/faustbrian/go-service v1.0.0
	github.com/faustbrian/go-telemetry v1.2.0
)

require (
	github.com/cenkalti/backoff/v5 v5.0.3 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/faustbrian/go-cli v1.0.0 // indirect
	github.com/faustbrian/go-clock v1.1.0 // indirect
	github.com/faustbrian/go-correlation v1.1.0 // indirect
	github.com/faustbrian/go-identifier v1.0.0 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/grpc-ecosystem/grpc-gateway/v2 v2.29.0 // indirect
	github.com/jackc/pgx/v5 v5.10.0 // indirect
	github.com/jpillora/backoff v1.0.0 // indirect
	github.com/robfig/cron/v3 v3.0.1 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/otel v1.44.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc v1.44.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetrichttp v1.44.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlptrace v1.44.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc v1.44.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp v1.44.0 // indirect
	go.opentelemetry.io/otel/metric v1.44.0 // indirect
	go.opentelemetry.io/otel/sdk v1.44.0 // indirect
	go.opentelemetry.io/otel/sdk/metric v1.44.0 // indirect
	go.opentelemetry.io/otel/trace v1.44.0 // indirect
	go.opentelemetry.io/proto/otlp v1.10.0 // indirect
	golang.org/x/net v0.58.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
	google.golang.org/genproto/googleapis/api v0.0.0-20260526163538-3dc84a4a5aaa // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20260526163538-3dc84a4a5aaa // indirect
	google.golang.org/grpc v1.83.2 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)

replace github.com/faustbrian/go-authentication => /private/tmp/identity-authentication-slog.XOdDBw/snapshots/authentication

replace github.com/faustbrian/go-authorization => /private/tmp/identity-authentication-slog.XOdDBw/snapshots/authorization

replace github.com/faustbrian/go-capability => /private/tmp/identity-authentication-slog.XOdDBw/snapshots/capability
