module example.invalid/authentication-clean-consumer

go 1.26.0

require github.com/faustbrian/go-authentication v1.0.0
