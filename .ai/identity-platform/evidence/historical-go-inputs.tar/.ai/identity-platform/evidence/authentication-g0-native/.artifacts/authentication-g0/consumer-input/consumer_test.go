package consumer

import (
	"testing"
	"time"
	auth "github.com/faustbrian/go-authentication"
)

func TestCleanConsumer(t *testing.T) {
	now := time.Date(2026, 10, 1, 12, 0, 0, 0, time.UTC)
	proof, err := auth.NewProof(auth.ProofSpec{ID: "abcdefghijklmnopqrstuv", Tenant: "tenant", Subject: "subject", Purpose: "sign-in", Audience: "resource", IssuedAt: now, ExpiresAt: now.Add(time.Minute), Method: "password", Assurance: auth.AssuranceSingleFactor})
	if err != nil { t.Fatal(err) }
	if err := proof.Validate(auth.ProofUse{Tenant: "tenant", Subject: "subject", Purpose: "sign-in", Audience: "resource", Now: now}); err != nil { t.Fatal(err) }
	if _, err := auth.NewOneTimeCode("1234"); err != nil { t.Fatal(err) }
	_ = auth.NewBearerCredential("synthetic")
}
